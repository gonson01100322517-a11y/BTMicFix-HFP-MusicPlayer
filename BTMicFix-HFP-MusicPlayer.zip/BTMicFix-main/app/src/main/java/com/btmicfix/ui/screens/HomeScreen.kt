package com.btmicfix.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.MusicNote

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.btmicfix.audio.AudioRoutingManager
import com.btmicfix.audio.HfpMusicPlayer
import com.btmicfix.audio.AudioRoutingManager.RoutingState
import com.btmicfix.shizuku.ShizukuManager
import com.btmicfix.ui.components.DeviceSelector
import com.btmicfix.ui.components.ShizukuStatusCard
import com.btmicfix.ui.components.StatusCard
import com.btmicfix.ui.theme.*

/**
 * Main dashboard screen.
 *
 * Shows the current routing status, available Bluetooth devices,
 * Shizuku status, and provides manual routing controls.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    audioRoutingManager: AudioRoutingManager,
    hfpMusicPlayer: HfpMusicPlayer,
    shizukuManager: ShizukuManager,
    onSetupClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val routingState by audioRoutingManager.routingState.collectAsState()
    val availableDevices by audioRoutingManager.availableDevices.collectAsState()
    val isPlaying by hfpMusicPlayer.isPlaying.collectAsState()
    val trackName by hfpMusicPlayer.trackName.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val route = audioRoutingManager.routeToFirstAvailableBluetooth()
            if (route is RoutingState.Active) {
                hfpMusicPlayer.play(it, it.lastPathSegment)
            }
        }
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "BTMicFix",
                        fontWeight = FontWeight.Bold,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark,
                    titleContentColor = Purple80,
                ),
                actions = {
                    IconButton(onClick = onSetupClick) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Setup",
                            tint = Purple80,
                        )
                    }
                },
            )
        },
        containerColor = SurfaceDark,
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Primary status card
            StatusCard(routingState = routingState)

            // Route / Stop button
            RoutingControlButton(
                routingState = routingState,
                onEnableRouting = {
                    audioRoutingManager.routeToFirstAvailableBluetooth()
                },
                onDisableRouting = {
                    audioRoutingManager.clearRouting()
                },
                onRetry = {
                    audioRoutingManager.routeToFirstAvailableBluetooth()
                },
            )

            // HFP music controls
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("HFP Music Player", style = MaterialTheme.typography.titleMedium)
                    Text(
                        trackName ?: "Choose an audio file. It will be sent through the HFP/SCO communication path.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.MusicNote, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Choose song")
                        }
                        if (isPlaying) {
                            OutlinedButton(onClick = { hfpMusicPlayer.pause() }) { Text("Pause") }
                        } else if (trackName != null) {
                            OutlinedButton(onClick = { hfpMusicPlayer.resume() }) { Text("Play") }
                        }
                    }
                    if (trackName != null) {
                        TextButton(onClick = { hfpMusicPlayer.stop() }) { Text("Stop") }
                    }
                }
            }

            // Available Bluetooth devices
            DeviceSelector(
                devices = availableDevices,
                onDeviceSelected = { device ->
                    audioRoutingManager.routeToBluetooth(device.deviceInfo)
                },
            )

            // Shizuku status (optional)
            ShizukuStatusCard(shizukuManager = shizukuManager)

            // How it works explainer
            HowItWorksCard()

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * Main routing control button — changes label/action based on current state.
 */
@Composable
private fun RoutingControlButton(
    routingState: RoutingState,
    onEnableRouting: () -> Unit,
    onDisableRouting: () -> Unit,
    onRetry: () -> Unit,
) {
    when (routingState) {
        is RoutingState.Idle -> {
            Button(
                onClick = onEnableRouting,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple40),
            ) {
                Icon(
                    imageVector = Icons.Default.PowerSettingsNew,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Enable Routing", style = MaterialTheme.typography.labelLarge)
            }
        }
        is RoutingState.Routing -> {
            Button(
                onClick = { },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                enabled = false,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StatusRouting.copy(alpha = 0.3f),
                    disabledContainerColor = StatusRouting.copy(alpha = 0.2f),
                ),
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = StatusRouting,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "Routing…",
                    style = MaterialTheme.typography.labelLarge,
                    color = StatusRouting,
                )
            }
        }
        is RoutingState.Active -> {
            OutlinedButton(
                onClick = onDisableRouting,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusActive),
            ) {
                Icon(
                    imageVector = Icons.Default.PowerSettingsNew,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Disable Routing", style = MaterialTheme.typography.labelLarge)
            }
        }
        is RoutingState.Failed -> {
            Button(
                onClick = onRetry,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StatusFailed.copy(alpha = 0.8f)),
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Retry", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

/**
 * Informational card explaining how the app works.
 */
@Composable
private fun HowItWorksCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = "How it works",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )

            val steps = listOf(
                "The app selects your Bluetooth device as the Android communication device.",
                "That activates the HFP/SCO voice channel when the device supports it.",
                "HFP Music Player sends the selected song through that communication audio path.",
                "HFP has telephone-like bandwidth, so music quality will be limited and usually mono.",
            )

            steps.forEachIndexed { index, step ->
                Row {
                    Text(
                        text = "${index + 1}.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Purple40,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(20.dp),
                    )
                    Text(
                        text = step,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
