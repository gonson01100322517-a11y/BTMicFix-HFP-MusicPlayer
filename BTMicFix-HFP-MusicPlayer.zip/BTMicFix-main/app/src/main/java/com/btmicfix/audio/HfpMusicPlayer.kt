package com.btmicfix.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import com.btmicfix.util.Logger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Plays a selected audio file using the communication/HFP audio path. */
class HfpMusicPlayer(private val context: Context) {
    private val audioManager = context.getSystemService(AudioManager::class.java)
    private var player: MediaPlayer? = null
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()
    private val _trackName = MutableStateFlow<String?>(null)
    val trackName: StateFlow<String?> = _trackName.asStateFlow()

    fun play(uri: Uri, displayName: String? = null) {
        stop()
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(context, uri)
                setOnPreparedListener {
                    it.start()
                    _isPlaying.value = true
                    Logger.i("HFP music started: ${displayName ?: uri}")
                }
                setOnCompletionListener {
                    _isPlaying.value = false
                }
                setOnErrorListener { _, what, extra ->
                    Logger.e("MediaPlayer error: $what/$extra")
                    _isPlaying.value = false
                    true
                }
                prepareAsync()
            }
            player = mp
            _trackName.value = displayName ?: "Selected audio"
        } catch (e: Exception) {
            Logger.e("Could not start HFP music", e)
            stop()
        }
    }

    fun pause() {
        player?.let { if (it.isPlaying) it.pause() }
        _isPlaying.value = false
    }

    fun resume() {
        player?.let { if (!it.isPlaying) it.start() }
        _isPlaying.value = player?.isPlaying == true
    }

    fun stop() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        _isPlaying.value = false
        _trackName.value = null
    }

    fun release() = stop()
}
